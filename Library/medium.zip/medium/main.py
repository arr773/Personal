
# Import Multiplication from your library
from medium_multi.multi import Multiplication

# Instantiate a Multiplication object
multiplication = Multiplication(2)

# Call the multiply method
print(multiplication.multiply(5))