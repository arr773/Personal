The assignment is written in ipynb format and can be run using the jupyter notebook

The data files are attached to the directory, in case of data not loading please check the path

There are no specific instructions to run the file
