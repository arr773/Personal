rm -rf *.csv

